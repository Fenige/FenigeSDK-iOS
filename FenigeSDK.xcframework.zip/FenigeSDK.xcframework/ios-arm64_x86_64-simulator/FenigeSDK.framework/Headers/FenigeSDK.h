//
//  FenigeSDK.h
//  FenigeSDK
//
//  Created by Dmytro Onyshchuk on 03.06.2024.
//

#import <Foundation/Foundation.h>

//! Project version number for FenigeSDK.
FOUNDATION_EXPORT double FenigeSDKVersionNumber;

//! Project version string for FenigeSDK.
FOUNDATION_EXPORT const unsigned char FenigeSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FenigeSDK/PublicHeader.h>

#import <FenigeSDK/FenigeSDK.h>
